<?php $__env->startSection('content'); ?>
<section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_2.jpg');" data-stellar-background-ratio="0.5">
<div class="overlay"></div>
<div class="container">
<div class="row no-gutters slider-text align-items-end">
  <div class="col-md-9 ftco-animate pb-5">
      <p class="breadcrumbs mb-2"><span class="mr-2"><a href="/">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Blog <i class="ion-ios-arrow-forward"></i></span></p>
    <h1 class="mb-0 bread">Blog</h1>
  </div>
</div>
</div>
</section>

<?php if(!empty($posts)): ?>
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section class="ftco-section">
<div class="container">
<div class="jumbotron"> 
<div class="row d-flex">
  <div class="col-md-4 d-flex ftco-animate">
    <div class="blog-entry align-self-stretch">
      <a href="" class="" style=""></a>
      <div class="text mt-3">
          <div class="meta mb-2">
          <div><a href="#"><?php echo e($post->created_at); ?></a></div>
          <div><a href="#"><?php echo e($post->post_category); ?></a></div>
          <div><a href="#" class="meta-chat"><span class="fa fa-comment"></span> 3</a></div>
        </div>
      <h3 class="heading"><a href=""><?php echo e($post->post_title); ?></a></h3>
      </div>
    </div>
  </div>
  </div>
</div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>

<div class="row mt-5">
  <div class="col text-center">
    <div class="block-27">
      <ul>
        <li><a href="#">&lt;</a></li>
        <li class="active"><span>1</span></li>
        <li><a href="#">2</a></li>
        <li><a href="#">3</a></li>
        <li><a href="#">4</a></li>
        <li><a href="#">5</a></li>
        <li><a href="#">&gt;</a></li>
      </ul>
    </div>
  </div>
</div>
</div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AYapp\resources\views/website/blog.blade.php ENDPATH**/ ?>