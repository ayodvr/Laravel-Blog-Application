<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card"  style="margin-top:10px">
                <div>
                    <a href="posts/create" class ="btn btn-primary">Create Post</a>
                    <a href="categories/create" class ="btn btn-info pull-right">Create Category</a>
                </div>
                <div></div>
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                        <div id="blog" class="row"> 
                            <div class="col-sm-2 paddingTop20">
                                <nav class="nav-sidebar">
                                    <ul class="nav">
                                        <li class="active"><a href="javascript:;">All Posts</a></li>
                                        <li class="nav-divider"></li>
                                    </ul>
                                </nav>
                            </div>
                           <div class="col-md-10 blogShort"> 
                           <?php if(count($myposts) > 0): ?>
                                <?php $__currentLoopData = $myposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <div>
                                    <h3><?php echo e($post['post_title']); ?></h3>
                                    <img src="/storage/cover_images/<?php echo e($post->cover_image); ?>" alt="post img" class="pull-left img-responsive thumb margin10 img-thumbnail">
                                        
                                            <em>Written <?php echo e($post['created_at']->diffForHumans()); ?><a target="_blank"> by <?php echo e($post->user->name); ?>  </a></em>
                    
                                        <a class="btn btn-xs btn-primary pull-right marginBottom20" href="/posts/<?php echo e($post->id); ?>">READ MORE</a>
                                   </div>
                                        <br>
                                        <hr style="margin-bottom:10px">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                            <?php else: ?>
                               <h1>Oops! You have no post.</h1> 
                            <?php endif; ?>  
                        </div>         
                        </div>
            </div>
            <?php echo e($myposts->links()); ?>

        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AYapp\resources\views/home.blade.php ENDPATH**/ ?>