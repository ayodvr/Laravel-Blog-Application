<?php $__env->startSection('content'); ?>
        <h1 class="text-center">Create Category</h1>

        <?php echo Form::open(['route' => 'categories.store', 'method' => 'POST']); ?>

                <div class="form-group" style="width:90%; margin:auto">
                    <?php echo e(Form::label('description', 'Description')); ?>

                   <?php echo e(Form::text('description','',['class'=>'form-control'])); ?>

                 
                </div>
                <div class="text-center" style="width:90%; margin:auto; padding-top:5px">
                   <?php echo e(Form::submit('Save Category',['class' =>'btn btn-success'])); ?>

                </div>
        <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AYapp\resources\views/categories/create.blade.php ENDPATH**/ ?>