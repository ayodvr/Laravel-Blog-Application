<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body>
    <h2>Welcome Home</h2>
    <p>This is the homepageThis is the homepage
    This is the homepageThis is the homepageThis is the homepage</p>
    <p>This is the homepageThis is the homepage
    This is the homepageThis is the homepageThis is the homepage</p>
    <p>This is the homepageThis is the homepage
    This is the homepageThis is the homepageThis is the homepage</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\AYapp\resources\views/website/home.blade.php ENDPATH**/ ?>