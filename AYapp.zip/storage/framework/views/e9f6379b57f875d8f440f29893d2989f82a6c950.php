<?php $__env->startSection('content'); ?>
  <section class="hero-wrap hero-wrap-2" style="background-image: url('/storage/resized-news-banner.jpg');" data-stellar-background-ratio="0.5">
  <div class="overlay"></div>
  <div class="container">
  <div class="row no-gutters slider-text align-items-end">
    <div class="col-md-9 ftco-animate pb-5">
        <p class="breadcrumbs mb-2"><span class="mr-2"><a href="#"><i class="ion-ios-arrow-forward"></i></a></span> <span class="mr-2"><a href="#"> <i class="ion-ios-arrow-forward"></i></a></span><span><i class="ion-ios-arrow-forward"></i></span></p>
    </div>
  </div>
  </div>
  </section>

  <section class="ftco-section ftco-degree-bg">
  <div class="container">
  <div class="row">
    <div class="col-md-8 ftco-animate">
      <em>Published <?php echo e($post['created_at']->toDayDateTimeString()); ?><a target="_blank"> by <b><?php echo e($post->user->name); ?> </b> </a></em>
      <h1 class="mb-3"><?php echo e($post->post_title); ?></h1>
      <p>
        <img src="/storage/cover_images/<?php echo e($post->cover_image); ?>" style ="width:100%" alt="" class="img-fluid">
      </p>
      <p><?php echo $post->post_body; ?></p>
    </div> <!-- .col-md-8 -->
  </div> 
  </div>
  </section> <!-- .section -->
  <hr>
  <?php if(!Auth::guest()): ?>
    <?php if(Auth::user()->id == $post->user_id): ?>
          <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-primary" style="margin-left:10vpx">Edit</a>
          <?php echo Form::open(['route'=>['posts.destroy',$post->id],'method'=>'POST','class'=>'pull-right']); ?>

                <?php echo e(Form::hidden('_method','DELETE')); ?>

                <?php echo e(Form::submit('DELETE', ['class' =>'btn btn-danger'])); ?>

          <?php echo Form::close(); ?>

    <?php endif; ?>
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AYapp\resources\views/posts/singlepost.blade.php ENDPATH**/ ?>