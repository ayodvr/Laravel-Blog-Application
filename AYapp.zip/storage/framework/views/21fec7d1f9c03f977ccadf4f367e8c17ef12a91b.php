    
    <?php $__env->startSection('content'); ?>
    <div class="hero-wrap">
		<?php if(!empty($posts)): ?>
	    <div class="home-slider owl-carousel">
			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="slider-item" style="background-image:url('/storage/cover_images/<?php echo e($post->cover_image); ?>');">
	      	<div class="overlay"></div>
	        <div class="container">
	          <div class="row no-gutters slider-text align-items-center justify-content-center">
		          <div class="col-md-10 ftco-animate">
		          	<div class="text w-100 text-center">
					  <h1 class="mb-4"><?php echo e($post->post_title); ?></h1>
					  <p><a href="/posts/<?php echo e($post->id); ?>" class="btn btn-blog">Read More</a></p>
		            </div>
		          </div>
		        </div>
	        </div>
		  </div>
		  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<?php endif; ?>
	  </div>
	  <section class="ftco-section">
		<div class="container">
			<?php if(count($posts) > 0): ?>
			<div class="row d-flex">
				<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-4 d-flex ftco-animate">
					<div class="blog-entry align-self-stretch">
					<a href="/posts/<?php echo e($blog->id); ?>" class="block-20 rounded" style="background-image: url('/storage/cover_images/<?php echo e($blog->cover_image); ?>');">
					  </a>
					  <div class="text mt-3">
						  <div class="meta mb-2">
						  <div><a><?php echo e($blog->created_at->toFormattedDateString()); ?></a></div>
						  <div><a>by <?php echo e($blog->user->name); ?></a></div>
						  <div><a class="meta-chat"><span class="fa fa-comment"></span></a></div>
						</div>
						<h1 class="heading"><a href="/posts/<?php echo e($blog->id); ?>"><?php echo e($blog->post_title); ?></a></h1>
					  </div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<?php endif; ?>
			<?php echo e($posts->links()); ?>

		</div>
	  </section>
 <?php $__env->stopSection(); ?>
    


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AYapp\resources\views/website/index.blade.php ENDPATH**/ ?>