<?php $__env->startSection('content'); ?>
  <section class="hero-wrap hero-wrap-2" style="background-image: url('/storage/resized-news-banner.jpg');" data-stellar-background-ratio="0.5">
  <div class="overlay"></div>
  <div class="container">
  <div class="row no-gutters slider-text align-items-end">
    <div class="col-md-9 ftco-animate pb-5">
        <p class="breadcrumbs mb-2"><span class="mr-2"><a href="/">Home <i class="ion-ios-arrow-forward"></i></a></span> <span class="mr-2"><a href="/posts">Blog <i class="ion-ios-arrow-forward"></i></a></span><span><i class="ion-ios-arrow-forward"></i></span></p>
      <h1 class="mb-0 bread">Blog</h1>
    </div>
  </div>
  </div>
  </section>

  <section class="ftco-section ftco-degree-bg">
    <h3><?php if(isset($cat_name) && $cat_name != ""): ?> <?php echo e($cat_name); ?> Posts <?php else: ?> All Posts <?php endif; ?></h3>
  <div class="container">
  <div class="row d-flex">
    <?php if(!empty($posts)): ?>
    <div class="col-md-9 ftco-animate">
      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="blog-entry align-self-stretch">
        <a class="block-20 rounded" style="background-image: url('/storage/cover_images/<?php echo e($cat->cover_image); ?>')"></a>
        <div class="text mt-3">
         <h3 class="heading"><a href="/posts/<?php echo e($cat->id); ?>"><?php echo e($cat->post_title); ?></a></h3>
         <a >Published&nbsp;<?php echo e($cat->created_at->diffForHumans()); ?> by <b><?php echo e($cat->user->name); ?></b></a>
        </div>   
    </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

    <div class="col-md-3 sidebar pl-md-5 ftco-animate">
      <div class="sidebar-box">
        <div class="sidebar-box ftco-animate">
          <div class="categories">
            <?php if(!empty($categories)): ?>
            <h3>Categories</h3>
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                <a href="/posts/all/<?php echo e($category->id); ?>"><?php echo e($category->description); ?>&nbsp;-&nbsp;(<?php echo e($category->posts_count); ?>)</a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
            <?php endif; ?>
        </div>
      </div>
    </div>
  </div> 
  <?php echo e($posts->links()); ?>

  </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AYapp\resources\views/categories/index.blade.php ENDPATH**/ ?>